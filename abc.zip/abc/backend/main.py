from fastapi import FastAPI, UploadFile, File
import random

app = FastAPI()

@app.get("/")
def home():
    return {"message": "Supplier ESG AI API Running"}

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):

    # Fake AI scoring for demo
    scores = {
        "environment": random.randint(50, 90),
        "social": random.randint(50, 90),
        "governance": random.randint(50, 90),
        "diversity": random.randint(40, 85)
    }

    return {
        "filename": file.filename,
        "scores": scores
    }