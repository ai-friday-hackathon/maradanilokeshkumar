import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <div style={navStyle}>
      <h2>Supplier ESG AI</h2>

      <div>
        <Link to="/">Home</Link> | 
        <Link to="/dashboard"> Dashboard</Link> |
        <Link to="/upload"> Upload</Link>
      </div>
    </div>
  );
}

const navStyle = {
  display: "flex",
  justifyContent: "space-between",
  padding: "15px",
  background: "#0a2540",
  color: "white"
};