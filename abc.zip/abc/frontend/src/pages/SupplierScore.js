export default function SupplierScore() {

  const scores = JSON.parse(localStorage.getItem("scores"));

  return (
    <div style={{padding:"30px"}}>

      <h1>Supplier Scorecard</h1>

      <table border="1" cellPadding="10">

        <tr>
          <th>Category</th>
          <th>Score</th>
        </tr>

        <tr>
          <td>Environment</td>
          <td>{scores.environment}</td>
        </tr>

        <tr>
          <td>Social</td>
          <td>{scores.social}</td>
        </tr>

        <tr>
          <td>Governance</td>
          <td>{scores.governance}</td>
        </tr>

        <tr>
          <td>Diversity</td>
          <td>{scores.diversity}</td>
        </tr>

      </table>

    </div>
  );
}