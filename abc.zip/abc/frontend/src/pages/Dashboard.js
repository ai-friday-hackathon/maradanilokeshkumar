import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement } from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement);

export default function Dashboard() {

  const data = {
    labels: ["Environment", "Social", "Governance", "Diversity"],
    datasets: [
      {
        label: "Average ESG Score",
        data: [78, 70, 75, 60]
      }
    ]
  };

  return (
    <div style={{padding:"30px"}}>

      <h1>Supplier ESG Dashboard</h1>

      <div style={{display:"flex", gap:"20px"}}>

        <div style={card}>Total Suppliers <h2>30</h2></div>
        <div style={card}>High Risk <h2>5</h2></div>
        <div style={card}>Avg ESG <h2>72</h2></div>
        <div style={card}>Diversity Score <h2>64%</h2></div>

      </div>

      <div style={{width:"500px", marginTop:"40px"}}>
        <Bar data={data} />
      </div>

    </div>
  );
}

const card = {
  border:"1px solid #ddd",
  padding:"20px",
  width:"180px",
  textAlign:"center",
  borderRadius:"8px"
};