import "./LandingPage.css";

export default function LandingPage() {
  return (
    <div className="landing-container">

      {/* NAVBAR */}

      <nav className="navbar">

  <div className="logo">
    Supplier ESG AI
  </div>

  <div className="menu">

    <a href="#about" className="menu-link">
      About
    </a>

    <a href="#contact" className="menu-link">
      Contact
    </a>

    <a href="/login">
<button className="login-btn">Login</button>
</a>

  </div>

</nav>


      {/* HERO SECTION */}

      <div className="hero">

        <div className="hero-text">

          <h1>
            Global Sustainability,
            <br />
            One Platform.
          </h1>

          <p>
            Trusted Data for Resilient Supply Chains.
          </p>

          <button className="cta-btn">
            ASSESS MY SUPPLIERS
          </button>

        </div>

        <div className="hero-image">

          <img
            src="https://images.unsplash.com/photo-1556740749-887f6717d7e4"
            alt="dashboard"
          />

        </div>

      </div>


      {/* ABOUT SECTION */}

      <div id="about" className="about-section">

        <h2>From Risk & Compliance to Value & Impact</h2>

        <p>
        Our AI-powered Supplier Sustainability & Diversity Risk Scorer helps organizations
        evaluate suppliers across Environmental, Social, Governance, and Diversity
        dimensions. By analyzing ESG reports, audit documents, and supplier policies,
        the platform automatically generates risk insights and sustainability scores,
        enabling smarter and more responsible procurement decisions.
        </p>

      </div>


      {/* FEATURES SECTION */}

      <div className="features">

        <div className="card">
          <h3>AI ESG Analysis</h3>
          <p>
          Automatically analyze supplier ESG reports and extract sustainability signals.
          </p>
        </div>

        <div className="card">
          <h3>Supplier Risk Scoring</h3>
          <p>
          Generate Environment, Social, Governance, and Diversity scores instantly.
          </p>
        </div>

        <div className="card">
          <h3>Explainable Insights</h3>
          <p>
          AI highlights why a supplier scored low and what evidence was found.
          </p>
        </div>

        <div className="card">
          <h3>Corrective Actions</h3>
          <p>
          Get recommended sustainability improvements for suppliers automatically.
          </p>
        </div>

      </div>


      {/* CONTACT SECTION */}

      <div id="contact" className="contact-section">

        <h2>Contact Us</h2>

        <p>
        Interested in building sustainable supply chains? Connect with our team
        to learn how AI-powered ESG analytics can transform your procurement.
        </p>

        <button className="contact-btn-large">
          Get in Touch
        </button>

      </div>

    </div>
  );
}