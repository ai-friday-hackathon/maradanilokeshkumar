export default function RiskInsights() {

  return (
    <div style={{padding:"30px"}}>

      <h1>AI Risk Insights</h1>

      <ul>
        <li>No carbon reduction targets detected</li>
        <li>Limited diversity program</li>
        <li>Weak governance policy disclosure</li>
      </ul>

    </div>
  );
}