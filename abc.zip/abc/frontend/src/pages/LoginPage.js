import { useState } from "react";
import "./LoginPage.css";

export default function LoginPage() {

  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="login-container">

      {/* LANGUAGE SELECTOR */}

      


      {/* CENTER HEADER */}

      <div className="login-brand">

        <p className="brand-subtitle">
          Sustainability Risk Intelligence Platform
        </p>

      </div>


      {/* LOGIN CARD */}

      <div className="login-card">

        <h2>Welcome Back</h2>

        <p className="subtitle">
          Access your Supplier Sustainability Dashboard
        </p>


        <input
          className="input-field"
          placeholder="Username / Email"
        />


        <div className="password-wrapper">

          <input
            type={showPassword ? "text" : "password"}
            className="input-field"
            placeholder="Password"
          />

          <span
            className="eye"
            onClick={() => setShowPassword(!showPassword)}
          >
            👁
          </span>

        </div>


        <button className="login-button">
          Log in
        </button>


        <a href="#" className="forgot">
          Forgot your password?
        </a>

      </div>


      {/* FOOTER */}

      <div className="login-footer">

        © 2026 Supplier ESG AI | Sustainability Risk Intelligence Platform

      </div>

    </div>
  );
}