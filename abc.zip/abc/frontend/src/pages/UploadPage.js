import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function UploadPage() {

  const navigate = useNavigate();

  const uploadFile = async (e) => {

    const file = e.target.files[0];

    const formData = new FormData();
    formData.append("file", file);

    const res = await axios.post("http://127.0.0.1:8000/upload", formData);

    localStorage.setItem("scores", JSON.stringify(res.data.scores));

    navigate("/score");
  };

  return (
    <div style={{padding:"40px"}}>

      <h2>Upload Supplier ESG Document</h2>

      <input type="file" onChange={uploadFile} />

    </div>
  );
}